// Main application logic
class PausenaufsichtApp {
    constructor() {
        this.authenticated = false;
        this.isAdmin = false;
        this.currentSchedule = null;
        this.teachers = [];
        this.areas = [];
        this.timeSlots = [];
        this.selectedTeacher = null;
        this.currentAssignmentContext = null;
        
        this.init();
    }

    async init() {
        // Check authentication status
        await this.checkAuthStatus();
        
        // Setup event listeners
        this.setupEventListeners();
        
        // Initialize WebSocket connection if authenticated
        if (this.authenticated) {
            window.wsManager.connect();
            this.showApp();
            this.setDefaultDates();
            await this.loadInitialData();
        } else {
            this.showLogin();
        }
    }

    async checkAuthStatus() {
        try {
            const response = await fetch('/api/auth-status');
            const data = await response.json();
            this.authenticated = data.authenticated;
            this.isAdmin = data.isAdmin;
        } catch (error) {
            console.error('Error checking auth status:', error);
            this.authenticated = false;
            this.isAdmin = false;
        }
    }

    setupEventListeners() {
        // Login form
        document.getElementById('loginForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });

        // Logout button
        document.getElementById('logoutBtn').addEventListener('click', () => {
            this.handleLogout();
        });

        // Load schedule button
        document.getElementById('loadSchedule').addEventListener('click', () => {
            this.loadSchedule();
        });

        // Teacher modal events
        document.getElementById('closeTeacherModal').addEventListener('click', () => {
            this.hideTeacherModal();
        });

        document.getElementById('teacherSearch').addEventListener('input', (e) => {
            this.searchTeachers(e.target.value);
        });

        document.getElementById('confirmAssignment').addEventListener('click', () => {
            this.confirmAssignment();
        });

        document.getElementById('cancelAssignment').addEventListener('click', () => {
            this.hideTeacherModal();
        });

        document.getElementById('removeAssignment').addEventListener('click', () => {
            this.removeAssignment();
        });

        // Confirmation modal events
        document.getElementById('confirmYes').addEventListener('click', () => {
            this.handleConfirmation(true);
        });

        document.getElementById('confirmNo').addEventListener('click', () => {
            this.handleConfirmation(false);
        });

        // Close modals when clicking outside
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.hideAllModals();
            }
        });
    }

    async handleLogin() {
        const password = document.getElementById('password').value;
        const isAdmin = document.getElementById('isAdmin').checked;
        const errorDiv = document.getElementById('loginError');

        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ password, isAdmin })
            });

            const data = await response.json();

            if (response.ok) {
                this.authenticated = true;
                this.isAdmin = data.isAdmin;
                this.showApp();
                this.setDefaultDates();
                await this.loadInitialData();
                window.wsManager.connect();
                this.showStatusMessage('Erfolgreich angemeldet', 'success');
            } else {
                errorDiv.textContent = data.error || 'Anmeldung fehlgeschlagen';
            }
        } catch (error) {
            console.error('Login error:', error);
            errorDiv.textContent = 'Verbindungsfehler';
        }
    }

    async handleLogout() {
        try {
            await fetch('/api/logout', { method: 'POST' });
            this.authenticated = false;
            this.isAdmin = false;
            window.wsManager.disconnect();
            this.showLogin();
            this.showStatusMessage('Erfolgreich abgemeldet', 'success');
        } catch (error) {
            console.error('Logout error:', error);
            this.showStatusMessage('Fehler beim Abmelden', 'error');
        }
    }

    showLogin() {
        document.getElementById('loginModal').classList.remove('hidden');
        document.getElementById('app').classList.add('hidden');
        document.getElementById('password').value = '';
        document.getElementById('isAdmin').checked = false;
        document.getElementById('loginError').textContent = '';
    }

    showApp() {
        document.getElementById('loginModal').classList.add('hidden');
        document.getElementById('app').classList.remove('hidden');
        
        // Update user info
        const userInfo = document.getElementById('userInfo');
        userInfo.textContent = this.isAdmin ? 'Admin-Modus' : 'Benutzer-Modus';
    }

    setDefaultDates() {
        const today = new Date();
        const nextWeek = new Date(today);
        nextWeek.setDate(today.getDate() + 7);

        document.getElementById('startDate').value = today.toISOString().split('T')[0];
        document.getElementById('endDate').value = nextWeek.toISOString().split('T')[0];
    }

    async loadInitialData() {
        try {
            // Load teachers, areas, and time slots
            const [teachersResponse, areasResponse, timeSlotsResponse] = await Promise.all([
                fetch('/api/teachers'),
                fetch('/api/areas'),
                fetch('/api/time-slots')
            ]);

            this.teachers = await teachersResponse.json();
            this.areas = await areasResponse.json();
            this.timeSlots = await timeSlotsResponse.json();

            // Load initial schedule
            await this.loadSchedule();
        } catch (error) {
            console.error('Error loading initial data:', error);
            this.showStatusMessage('Fehler beim Laden der Daten', 'error');
        }
    }

    async loadSchedule() {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;

        if (!startDate || !endDate) {
            this.showStatusMessage('Bitte Start- und Enddatum auswählen', 'error');
            return;
        }

        this.showLoading(true);

        try {
            const response = await fetch(`/api/assignments/schedule?startDate=${startDate}&endDate=${endDate}`);
            
            if (!response.ok) {
                throw new Error('Failed to load schedule');
            }

            this.currentSchedule = await response.json();
            this.renderSchedule();
        } catch (error) {
            console.error('Error loading schedule:', error);
            this.showStatusMessage('Fehler beim Laden des Stundenplans', 'error');
        } finally {
            this.showLoading(false);
        }
    }

    renderSchedule() {
        const container = document.getElementById('scheduleGrid');
        container.innerHTML = '';

        if (!this.currentSchedule || !this.currentSchedule.dates.length) {
            container.innerHTML = '<p>Keine Daten für den ausgewählten Zeitraum gefunden.</p>';
            return;
        }

        this.currentSchedule.dates.forEach(date => {
            const dayElement = this.createDayElement(date);
            container.appendChild(dayElement);
        });

        document.getElementById('scheduleContainer').classList.remove('hidden');
    }

    createDayElement(date) {
        const dayDiv = document.createElement('div');
        dayDiv.className = 'schedule-day';

        const dateObj = new Date(date);
        const dayName = dateObj.toLocaleDateString('de-DE', { weekday: 'long' });
        const dateStr = dateObj.toLocaleDateString('de-DE');

        dayDiv.innerHTML = `
            <div class="day-header">
                <h3>${dayName}, ${dateStr}</h3>
            </div>
            <div class="day-content">
                ${this.currentSchedule.areas.map(area => this.createAreaSection(area, date)).join('')}
            </div>
        `;

        return dayDiv;
    }

    createAreaSection(area, date) {
        return `
            <div class="area-section">
                <div class="area-header">
                    <h4>${area.name} (${area.supervision_count} Aufsicht${area.supervision_count > 1 ? 'en' : ''})</h4>
                </div>
                <div class="time-slots">
                    ${this.currentSchedule.timeSlots.map(timeSlot => 
                        this.createTimeSlotElement(area, timeSlot, date)
                    ).join('')}
                </div>
            </div>
        `;
    }

    createTimeSlotElement(area, timeSlot, date) {
        const assignments = this.currentSchedule.assignments[date][area.id][timeSlot.id] || [];
        
        return `
            <div class="time-slot">
                <div class="time-slot-header">
                    ${timeSlot.display_name}
                </div>
                <div class="supervision-slots">
                    ${Array.from({ length: area.supervision_count }, (_, index) => {
                        const supervisionNumber = index + 1;
                        const assignment = assignments.find(a => a.supervision_number === supervisionNumber);
                        
                        return this.createSupervisionSlot(area, timeSlot, date, supervisionNumber, assignment);
                    }).join('')}
                </div>
            </div>
        `;
    }

    createSupervisionSlot(area, timeSlot, date, supervisionNumber, assignment) {
        const isEmpty = !assignment;
        const className = isEmpty ? 'supervision-slot empty' : 'supervision-slot filled';
        const content = isEmpty ? 'Leer' : assignment.teacher_name;
        
        const dataAttributes = [
            `data-area-id="${area.id}"`,
            `data-time-slot-id="${timeSlot.id}"`,
            `data-date="${date}"`,
            `data-supervision-number="${supervisionNumber}"`
        ];

        if (assignment) {
            dataAttributes.push(`data-assignment-id="${assignment.id}"`);
            dataAttributes.push(`data-teacher-id="${assignment.teacher_id}"`);
        }

        return `
            <div class="${className}" ${dataAttributes.join(' ')} onclick="app.handleSlotClick(this)">
                ${content}
            </div>
        `;
    }

    handleSlotClick(slotElement) {
        const areaId = parseInt(slotElement.dataset.areaId);
        const timeSlotId = parseInt(slotElement.dataset.timeSlotId);
        const date = slotElement.dataset.date;
        const supervisionNumber = parseInt(slotElement.dataset.supervisionNumber);
        const assignmentId = slotElement.dataset.assignmentId;
        const teacherId = slotElement.dataset.teacherId;

        // Find area and time slot info
        const area = this.areas.find(a => a.id === areaId);
        const timeSlot = this.timeSlots.find(ts => ts.id === timeSlotId);

        this.currentAssignmentContext = {
            areaId,
            timeSlotId,
            date,
            supervisionNumber,
            assignmentId: assignmentId ? parseInt(assignmentId) : null,
            teacherId: teacherId ? parseInt(teacherId) : null,
            area,
            timeSlot,
            slotElement
        };

        this.showTeacherModal();
    }

    showTeacherModal() {
        const modal = document.getElementById('teacherModal');
        const context = this.currentAssignmentContext;

        // Update modal info
        document.getElementById('modalAreaName').textContent = context.area.name;
        document.getElementById('modalTimeSlot').textContent = context.timeSlot.display_name;
        document.getElementById('modalDate').textContent = new Date(context.date).toLocaleDateString('de-DE');
        document.getElementById('modalSupervisionNumber').textContent = context.supervisionNumber;

        // Reset form
        document.getElementById('teacherSearch').value = '';
        document.getElementById('teacherResults').innerHTML = '';
        document.getElementById('confirmAssignment').disabled = true;
        this.selectedTeacher = null;

        // Show/hide remove button
        const removeBtn = document.getElementById('removeAssignment');
        if (context.assignmentId) {
            removeBtn.classList.remove('hidden');
            // Pre-fill with current teacher
            const currentTeacher = this.teachers.find(t => t.id === context.teacherId);
            if (currentTeacher) {
                document.getElementById('teacherSearch').value = currentTeacher.name;
                this.selectedTeacher = currentTeacher;
                document.getElementById('confirmAssignment').disabled = false;
            }
        } else {
            removeBtn.classList.add('hidden');
        }

        modal.classList.remove('hidden');
        document.getElementById('teacherSearch').focus();
    }

    hideTeacherModal() {
        document.getElementById('teacherModal').classList.add('hidden');
        this.currentAssignmentContext = null;
        this.selectedTeacher = null;
    }

    async searchTeachers(query) {
        if (query.length < 2) {
            document.getElementById('teacherResults').innerHTML = '';
            return;
        }

        try {
            const response = await fetch(`/api/teachers/search?q=${encodeURIComponent(query)}`);
            const teachers = await response.json();
            
            this.renderTeacherResults(teachers);
        } catch (error) {
            console.error('Error searching teachers:', error);
        }
    }

    renderTeacherResults(teachers) {
        const container = document.getElementById('teacherResults');
        
        if (teachers.length === 0) {
            container.innerHTML = '<div class="teacher-result">Keine Lehrkräfte gefunden</div>';
            return;
        }

        container.innerHTML = teachers.map(teacher => `
            <div class="teacher-result" onclick="app.selectTeacher(${teacher.id})">
                <div class="teacher-name">${teacher.name}</div>
                <div class="teacher-full-name">${teacher.foreName} ${teacher.longName}</div>
            </div>
        `).join('');
    }

    selectTeacher(teacherId) {
        this.selectedTeacher = this.teachers.find(t => t.id === teacherId);
        
        if (this.selectedTeacher) {
            document.getElementById('teacherSearch').value = this.selectedTeacher.name;
            document.getElementById('confirmAssignment').disabled = false;
            
            // Update visual selection
            document.querySelectorAll('.teacher-result').forEach(el => {
                el.classList.remove('selected');
            });
            event.target.closest('.teacher-result').classList.add('selected');
        }
    }

    async confirmAssignment() {
        if (!this.selectedTeacher || !this.currentAssignmentContext) {
            return;
        }

        const context = this.currentAssignmentContext;
        
        // Check if trying to overwrite existing assignment
        if (context.assignmentId && context.teacherId !== this.selectedTeacher.id) {
            const currentTeacher = this.teachers.find(t => t.id === context.teacherId);
            const message = `Diese Aufsicht ist bereits ${currentTeacher.name} zugewiesen. Möchten Sie sie ${this.selectedTeacher.name} zuweisen?`;
            
            if (!await this.showConfirmation(message)) {
                return;
            }
        }

        this.hideTeacherModal();
        context.slotElement.classList.add('updating');

        try {
            let response;
            
            if (context.assignmentId) {
                // Update existing assignment
                response = await fetch(`/api/assignments/${context.assignmentId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        teacherId: this.selectedTeacher.id
                    })
                });
            } else {
                // Create new assignment
                response = await fetch('/api/assignments', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        areaId: context.areaId,
                        timeSlotId: context.timeSlotId,
                        date: context.date,
                        teacherId: this.selectedTeacher.id,
                        supervisionNumber: context.supervisionNumber
                    })
                });
            }

            if (response.ok) {
                const assignment = await response.json();
                this.updateSlotElement(context.slotElement, assignment);
                this.showStatusMessage('Zuweisung erfolgreich gespeichert', 'success');
            } else {
                const error = await response.json();
                if (response.status === 409) {
                    this.showStatusMessage('Diese Aufsicht ist bereits vergeben', 'error');
                } else {
                    this.showStatusMessage(error.error || 'Fehler beim Speichern', 'error');
                }
            }
        } catch (error) {
            console.error('Error saving assignment:', error);
            this.showStatusMessage('Verbindungsfehler', 'error');
        } finally {
            context.slotElement.classList.remove('updating');
        }
    }

    async removeAssignment() {
        const context = this.currentAssignmentContext;
        
        if (!context.assignmentId) {
            return;
        }

        const message = 'Möchten Sie diese Zuweisung wirklich entfernen?';
        if (!await this.showConfirmation(message)) {
            return;
        }

        this.hideTeacherModal();
        context.slotElement.classList.add('updating');

        try {
            const response = await fetch(`/api/assignments/${context.assignmentId}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                this.resetSlotElement(context.slotElement);
                this.showStatusMessage('Zuweisung entfernt', 'success');
            } else {
                const error = await response.json();
                this.showStatusMessage(error.error || 'Fehler beim Entfernen', 'error');
            }
        } catch (error) {
            console.error('Error removing assignment:', error);
            this.showStatusMessage('Verbindungsfehler', 'error');
        } finally {
            context.slotElement.classList.remove('updating');
        }
    }

    updateSlotElement(slotElement, assignment) {
        slotElement.textContent = assignment.teacher_name;
        slotElement.className = 'supervision-slot filled';
        slotElement.dataset.assignmentId = assignment.id;
        slotElement.dataset.teacherId = assignment.teacher_id;
    }

    resetSlotElement(slotElement) {
        slotElement.textContent = 'Leer';
        slotElement.className = 'supervision-slot empty';
        delete slotElement.dataset.assignmentId;
        delete slotElement.dataset.teacherId;
    }

    showConfirmation(message) {
        return new Promise((resolve) => {
            document.getElementById('confirmMessage').textContent = message;
            document.getElementById('confirmModal').classList.remove('hidden');
            
            this.confirmationResolver = resolve;
        });
    }

    handleConfirmation(confirmed) {
        document.getElementById('confirmModal').classList.add('hidden');
        
        if (this.confirmationResolver) {
            this.confirmationResolver(confirmed);
            this.confirmationResolver = null;
        }
    }

    hideAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.add('hidden');
        });
    }

    showLoading(show) {
        const loadingIndicator = document.getElementById('loadingIndicator');
        const scheduleContainer = document.getElementById('scheduleContainer');
        
        if (show) {
            loadingIndicator.classList.remove('hidden');
            scheduleContainer.classList.add('hidden');
        } else {
            loadingIndicator.classList.add('hidden');
        }
    }

    showStatusMessage(message, type = 'info') {
        const container = document.getElementById('statusMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `status-message ${type}`;
        messageDiv.textContent = message;
        
        container.appendChild(messageDiv);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.parentNode.removeChild(messageDiv);
            }
        }, 5000);
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new PausenaufsichtApp();
    window.showStatusMessage = (message, type) => window.app.showStatusMessage(message, type);
});
